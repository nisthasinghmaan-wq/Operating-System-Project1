# Real-Time Multithreading Simulator

This project is a browser-based educational simulator for core operating system concepts. It visualizes:

- `Many-to-One`, `One-to-One`, and `Many-to-Many` multithreading models
- Thread states: `New`, `Ready`, `Running`, `Waiting`, and `Terminated`
- CPU scheduling using `Round Robin` and `FCFS`
- Synchronization using a `Semaphore` and a `Monitor`
- Blocking, waking, resource ownership, and kernel-thread mapping

## Project Structure

- `index.html` - dashboard layout and UI controls
- `styles.css` - responsive dashboard styling and state colors
- `js/config.js` - labels, colors, presets, and helper constants
- `js/simulator.js` - simulation engine, scheduling, mapping, and sync rules
- `js/render.js` - DOM rendering and SVG animation logic
- `js/main.js` - event wiring and application bootstrapping

## How to Run in VS Code

This simulator runs entirely in the browser. No database and no backend setup are required.

### Option 1: Live Server

1. Open the folder in VS Code.
2. Install the `Live Server` extension if you want automatic refresh.
3. Right-click `index.html`.
4. Choose `Open with Live Server`.

### Option 2: Open directly

1. Open the folder in VS Code.
2. Open `index.html` in File Explorer.
3. Double-click it to launch it in your browser.

## How to Use the Simulator

1. Choose the threading model, scheduling policy, and synchronization method.
2. Click `Create Thread` to add a new user thread.
3. Click `Run` for continuous execution.
4. Click `Pause` to stop the timer.
5. Click `Step` to execute exactly one scheduling tick.
6. Adjust `Simulation Speed`, `Time Slice`, and the initial semaphore value.
7. Click `Deadlock Demo` to load a high-contention monitor scenario.

## What to Observe

- In `Many-to-One`, one blocking thread can stall the whole user-thread group.
- In `One-to-One`, each user thread gets its own kernel-thread partner.
- In `Many-to-Many`, user threads are multiplexed over a smaller kernel-thread pool.
- In `Semaphore` mode, threads call `wait()` and `signal()`.
- In `Monitor` mode, only one thread owns the monitor while others wait on the condition queue.

## Beginner Notes

- The code is split into small modules so each concept is easier to study.
- The simulator uses random delays and randomized resource requests to make the animation feel alive.
- Comments focus on the core scheduling and synchronization ideas.
