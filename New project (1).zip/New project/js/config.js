export const MODEL_COPY = {
  "many-to-one":
    "In many-to-one, all user threads share one kernel execution context, so one blocking call can stop the entire process.",
  "one-to-one":
    "In one-to-one, every user thread maps to its own kernel thread, improving concurrency at the cost of more kernel overhead.",
  "many-to-many":
    "In many-to-many, many user threads are multiplexed across a smaller kernel-thread pool, balancing flexibility and scalability.",
};

export const SYNC_COPY = {
  semaphore:
    "Semaphore mode uses wait() and signal() to guard entry into the shared critical section.",
  monitor:
    "Monitor mode allows only one thread inside the monitor at a time, while blocked threads wait on a condition queue.",
};

export const SPEEDS = {
  1: { label: "Very Slow", delay: 1500 },
  2: { label: "Slow", delay: 1100 },
  3: { label: "Normal", delay: 800 },
  4: { label: "Fast", delay: 520 },
  5: { label: "Very Fast", delay: 260 },
};

export const STATE_COLORS = {
  New: "#7d5cff",
  Ready: "#13776f",
  Running: "#b88b19",
  Waiting: "#ae3b3b",
  Terminated: "#516072",
};

export const LANES = {
  new: { x: 90, y: 135, width: 170, height: 220, label: "New Threads" },
  ready: { x: 300, y: 60, width: 210, height: 340, label: "Ready Queue" },
  cpu: { x: 560, y: 105, width: 170, height: 160, label: "CPU" },
  wait: { x: 770, y: 60, width: 210, height: 340, label: "Waiting Queue" },
  done: { x: 1010, y: 135, width: 70, height: 220, label: "Terminated" },
  resource: { x: 560, y: 320, width: 250, height: 120, label: "Critical Resource" },
};

export const DEFAULT_THREADS = [
  {
    id: "T1",
    totalWork: 7,
    workLeft: 7,
    state: "New",
    resourceNeed: "Disk Buffer",
    actionScript: ["compute", "ready", "resource", "compute", "resource", "compute"],
    color: "#d96b40",
  },
  {
    id: "T2",
    totalWork: 6,
    workLeft: 6,
    state: "New",
    resourceNeed: "Print Queue",
    actionScript: ["compute", "resource", "compute", "compute", "resource"],
    color: "#1b8a7b",
  },
  {
    id: "T3",
    totalWork: 8,
    workLeft: 8,
    state: "New",
    resourceNeed: "Shared Cache",
    actionScript: ["compute", "compute", "resource", "compute", "resource"],
    color: "#9969d8",
  },
];
