import { Simulator } from "./simulator.js";
import { renderApp } from "./render.js";

const simulator = new Simulator();

const els = {
  tickValue: document.getElementById("tick-value"),
  policyValue: document.getElementById("policy-value"),
  modelValue: document.getElementById("model-value"),
  syncValue: document.getElementById("sync-value"),
  modelSelect: document.getElementById("model-select"),
  policySelect: document.getElementById("policy-select"),
  syncSelect: document.getElementById("sync-select"),
  speedControl: document.getElementById("speed-control"),
  speedLabel: document.getElementById("speed-label"),
  sliceControl: document.getElementById("slice-control"),
  sliceLabel: document.getElementById("slice-label"),
  semaphoreControl: document.getElementById("semaphore-control"),
  semaphoreLabel: document.getElementById("semaphore-label"),
  createThreadBtn: document.getElementById("create-thread-btn"),
  runBtn: document.getElementById("run-btn"),
  pauseBtn: document.getElementById("pause-btn"),
  stepBtn: document.getElementById("step-btn"),
  resetBtn: document.getElementById("reset-btn"),
  deadlockBtn: document.getElementById("deadlock-btn"),
  userCount: document.getElementById("user-count"),
  kernelCount: document.getElementById("kernel-count"),
  readyCount: document.getElementById("ready-count"),
  waitingCount: document.getElementById("waiting-count"),
  cpuLoad: document.getElementById("cpu-load"),
  mappingCopy: document.getElementById("mapping-copy"),
  systemCanvas: document.getElementById("system-canvas"),
  threadTableBody: document.getElementById("thread-table-body"),
  cpuCards: document.getElementById("cpu-cards"),
  waitingCards: document.getElementById("waiting-cards"),
  resourceCopy: document.getElementById("resource-copy"),
  semaphoreValue: document.getElementById("semaphore-value"),
  semaphoreStatus: document.getElementById("semaphore-status"),
  monitorOwner: document.getElementById("monitor-owner"),
  monitorStatus: document.getElementById("monitor-status"),
  conditionSize: document.getElementById("condition-size"),
  conditionStatus: document.getElementById("condition-status"),
  logList: document.getElementById("log-list"),
  legendHost: document.getElementById("visual-header"),
};

simulator.subscribe((snapshot) => {
  renderApp(snapshot, els);
});

els.modelSelect.addEventListener("change", (event) => simulator.setModel(event.target.value));
els.policySelect.addEventListener("change", (event) => simulator.setPolicy(event.target.value));
els.syncSelect.addEventListener("change", (event) => simulator.setSyncMode(event.target.value));
els.speedControl.addEventListener("input", (event) => simulator.setSpeed(event.target.value));
els.sliceControl.addEventListener("input", (event) => simulator.setTimeSlice(event.target.value));
els.semaphoreControl.addEventListener("input", (event) => simulator.setSemaphoreInitial(event.target.value));
els.createThreadBtn.addEventListener("click", () => simulator.createThread());
els.runBtn.addEventListener("click", () => simulator.start());
els.pauseBtn.addEventListener("click", () => simulator.pause());
els.stepBtn.addEventListener("click", () => {
  simulator.stop();
  simulator.step();
});
els.resetBtn.addEventListener("click", () => simulator.reset());
els.deadlockBtn.addEventListener("click", () => simulator.loadDeadlockDemo());
