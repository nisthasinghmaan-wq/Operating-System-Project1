import { LANES, SPEEDS, STATE_COLORS } from "./config.js";

function stateClass(state) {
  return `state-${state.toLowerCase()}`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function lanePosition(thread, threads) {
  const index = threads.filter((item) => item.state === thread.state).findIndex((item) => item.id === thread.id);
  if (thread.state === "New") return { x: LANES.new.x + 38, y: LANES.new.y + 40 + index * 58 };
  if (thread.state === "Ready") return { x: LANES.ready.x + 42, y: LANES.ready.y + 42 + index * 58 };
  if (thread.state === "Running") return { x: LANES.cpu.x + 62, y: LANES.cpu.y + 70 };
  if (thread.state === "Waiting") return { x: LANES.wait.x + 42, y: LANES.wait.y + 42 + index * 58 };
  return { x: LANES.done.x + 12, y: LANES.done.y + 40 + index * 44 };
}

function laneBox({ x, y, width, height, label, fill }) {
  return `<g><rect x="${x}" y="${y}" width="${width}" height="${height}" rx="24" fill="${fill}" stroke="rgba(29,36,48,0.12)" /><text x="${x + 18}" y="${y + 28}" fill="#5f6774" font-size="16" font-weight="600">${label}</text></g>`;
}

function threadNode(thread, position) {
  const stroke = thread.enteredCritical ? "#7c3516" : "rgba(29,36,48,0.18)";
  return `
    <g transform="translate(${position.x}, ${position.y})">
      <circle cx="20" cy="20" r="20" fill="${thread.color}" stroke="${stroke}" stroke-width="3" />
      <text x="20" y="25" fill="white" font-size="14" text-anchor="middle" font-weight="700">${thread.id}</text>
      <rect x="48" y="2" width="108" height="36" rx="14" fill="rgba(255,255,255,0.9)" stroke="rgba(29,36,48,0.08)" />
      <text x="58" y="17" fill="#1d2430" font-size="12" font-weight="700">${thread.state}</text>
      <text x="58" y="31" fill="#5f6774" font-size="11">${thread.kernelId} | ${thread.workLeft}/${thread.totalWork}</text>
    </g>
  `;
}

function connectionLine(x1, y1, x2, y2) {
  return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="rgba(124,53,22,0.22)" stroke-width="2.5" stroke-dasharray="10 8" />`;
}

function kernelThreadCards(kernelThreads) {
  return kernelThreads.map((kernel) => `<article class="lane-card"><strong>${kernel.id}</strong><p>${kernel.threadId === "Idle" ? "Idle" : `Running ${kernel.threadId}`}</p></article>`).join("");
}

function waitingCards(waitingThreads) {
  if (!waitingThreads.length) {
    return `<article class="lane-card"><strong>No waiting threads</strong><p>The waiting queue is empty right now.</p></article>`;
  }

  return waitingThreads.map((thread) => `<article class="lane-card"><strong>${thread.id}</strong><p>${escapeHtml(thread.blockedReason || "Waiting for resource.")}</p></article>`).join("");
}

function threadRows(threads) {
  return threads
    .map(
      (thread) => `
        <tr>
          <td>${thread.id}</td>
          <td><span class="state-chip ${stateClass(thread.state)} ${thread.enteredCritical ? "state-critical" : ""}">${thread.state}</span></td>
          <td>${thread.kernelId}</td>
          <td>${thread.workLeft}/${thread.totalWork}</td>
          <td>${thread.resourceNeed}</td>
          <td>${escapeHtml(thread.blockedReason || (thread.enteredCritical ? "Inside critical section" : "Ready for CPU work"))}</td>
        </tr>
      `
    )
    .join("");
}

function logEntries(logs) {
  return logs.map((entry) => `<article class="log-entry"><strong>Tick ${entry.tick}</strong><div>${escapeHtml(entry.message)}</div></article>`).join("");
}

function legendMarkup() {
  const items = Object.entries(STATE_COLORS)
    .map(([label, color]) => `<span class="legend-item"><span class="legend-dot" style="background:${color}"></span>${label}</span>`)
    .join("");
  return `<div class="legend-row">${items}</div>`;
}

export function renderApp(snapshot, els) {
  const ready = snapshot.threads.filter((thread) => thread.state === "Ready").length;
  const waiting = snapshot.threads.filter((thread) => thread.state === "Waiting").length;
  const running = snapshot.threads.filter((thread) => thread.state === "Running").length;
  const cpuLoad = Math.round((running / Math.max(snapshot.kernelThreads.length, 1)) * 100);

  els.tickValue.textContent = String(snapshot.tick);
  els.modelSelect.value = snapshot.model;
  els.policySelect.value = snapshot.policy;
  els.syncSelect.value = snapshot.syncMode;
  els.speedControl.value = String(snapshot.speed);
  els.sliceControl.value = String(snapshot.timeSlice);
  els.semaphoreControl.value = String(snapshot.semaphoreInitial);
  els.policyValue.textContent = snapshot.policy === "round-robin" ? "Round Robin" : "FCFS";
  els.modelValue.textContent = snapshot.model.replaceAll("-", " ").replace(/\b\w/g, (char) => char.toUpperCase());
  els.syncValue.textContent = snapshot.syncMode === "semaphore" ? "Semaphore" : "Monitor";
  els.userCount.textContent = String(snapshot.threads.length);
  els.kernelCount.textContent = String(snapshot.kernelThreads.length);
  els.readyCount.textContent = String(ready);
  els.waitingCount.textContent = String(waiting);
  els.cpuLoad.textContent = `${cpuLoad}%`;
  els.mappingCopy.textContent = snapshot.mappingText;
  els.resourceCopy.textContent = snapshot.resourceText;
  els.speedLabel.textContent = SPEEDS[snapshot.speed].label;
  els.sliceLabel.textContent = `${snapshot.timeSlice} tick${snapshot.timeSlice > 1 ? "s" : ""}`;
  els.semaphoreLabel.textContent = `${snapshot.semaphoreInitial} permit${snapshot.semaphoreInitial === 1 ? "" : "s"}`;
  els.semaphoreValue.textContent = String(snapshot.semaphoreValue);
  els.semaphoreStatus.textContent = snapshot.syncMode === "semaphore" ? "Threads call wait() before entering." : "Semaphore is inactive while monitor mode is selected.";
  els.monitorOwner.textContent = snapshot.monitorOwner ?? "None";
  els.monitorStatus.textContent = snapshot.syncMode === "monitor" ? "Exactly one thread can own the monitor lock." : "Monitor is inactive while semaphore mode is selected.";
  els.conditionSize.textContent = String(snapshot.conditionQueue.length);
  els.conditionStatus.textContent = snapshot.conditionQueue.length > 0 ? `${snapshot.conditionQueue.join(", ")} currently blocked.` : "No threads are blocked on the condition queue.";

  els.threadTableBody.innerHTML = threadRows(snapshot.threads);
  els.cpuCards.innerHTML = kernelThreadCards(snapshot.kernelThreads);
  els.waitingCards.innerHTML = waitingCards(snapshot.threads.filter((thread) => thread.state === "Waiting"));
  els.logList.innerHTML = logEntries(snapshot.logs);

  const laneMarkup = `
    ${laneBox({ ...LANES.new, fill: "rgba(125,92,255,0.08)" })}
    ${laneBox({ ...LANES.ready, fill: "rgba(19,119,111,0.08)" })}
    ${laneBox({ ...LANES.cpu, fill: "rgba(184,139,25,0.1)" })}
    ${laneBox({ ...LANES.wait, fill: "rgba(174,59,59,0.08)" })}
    ${laneBox({ ...LANES.done, fill: "rgba(81,96,114,0.1)" })}
    ${laneBox({ ...LANES.resource, fill: "rgba(181,92,52,0.08)" })}
    ${connectionLine(260, 245, 300, 245)}
    ${connectionLine(510, 185, 560, 185)}
    ${connectionLine(730, 185, 770, 185)}
    ${connectionLine(980, 245, 1010, 245)}
    <text x="580" y="370" fill="#1d2430" font-size="18" font-weight="700">${snapshot.syncMode === "semaphore" ? "Semaphore" : "Monitor"}</text>
    <text x="580" y="394" fill="#5f6774" font-size="13">${snapshot.syncMode === "semaphore" ? `Count = ${snapshot.semaphoreValue}` : `Owner = ${snapshot.monitorOwner ?? "None"}`}</text>
  `;

  // Re-rendering the SVG each tick keeps the state flow easy to understand.
  const threadMarkup = snapshot.threads.map((thread) => threadNode(thread, lanePosition(thread, snapshot.threads))).join("");
  els.systemCanvas.innerHTML = `${laneMarkup}${threadMarkup}`;

  if (!els.legendHost.dataset.loaded) {
    els.legendHost.insertAdjacentHTML("beforeend", legendMarkup());
    els.legendHost.dataset.loaded = "true";
  }
}
