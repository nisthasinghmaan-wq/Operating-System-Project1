import { DEFAULT_THREADS, MODEL_COPY, SPEEDS, SYNC_COPY } from "./config.js";

function cloneThread(thread) {
  return {
    ...thread,
    createdAt: 0,
    age: 0,
    quantumUsed: 0,
    kernelId: null,
    blockedReason: "",
    enteredCritical: false,
    waitDuration: 0,
    scriptIndex: 0,
    signalPending: false,
  };
}

function randomChoice(values) {
  return values[Math.floor(Math.random() * values.length)];
}

function nextThreadTemplate(index) {
  const palette = ["#d96b40", "#1b8a7b", "#9969d8", "#df8f2d", "#3270c9", "#cb4e79"];
  const resources = ["Disk Buffer", "Socket Table", "I/O Port", "Printer Spool", "Shared Cache"];
  const work = 5 + Math.floor(Math.random() * 5);
  return cloneThread({
    id: `T${index}`,
    totalWork: work,
    workLeft: work,
    state: "New",
    resourceNeed: randomChoice(resources),
    actionScript: [
      "compute",
      Math.random() > 0.45 ? "resource" : "compute",
      "compute",
      Math.random() > 0.55 ? "resource" : "compute",
      "compute",
    ],
    color: palette[(index - 1) % palette.length],
  });
}

export class Simulator {
  constructor() {
    this.listeners = new Set();
    this.timer = null;
    this.threadCounter = DEFAULT_THREADS.length;
    this.reset();
  }

  subscribe(listener) {
    this.listeners.add(listener);
    listener(this.getSnapshot());
    return () => this.listeners.delete(listener);
  }

  notify() {
    const snapshot = this.getSnapshot();
    this.listeners.forEach((listener) => listener(snapshot));
  }

  getSnapshot() {
    return {
      model: this.model,
      policy: this.policy,
      syncMode: this.syncMode,
      speed: this.speed,
      tick: this.tick,
      running: this.running,
      timeSlice: this.timeSlice,
      semaphoreValue: this.semaphoreValue,
      semaphoreInitial: this.semaphoreInitial,
      monitorOwner: this.monitorOwner,
      conditionQueue: [...this.conditionQueue],
      logs: [...this.logs],
      threads: this.threads.map((thread) => ({ ...thread })),
      deadlockMode: this.deadlockMode,
      mappingText: MODEL_COPY[this.model],
      resourceText: SYNC_COPY[this.syncMode],
      kernelThreads: this.buildKernelThreads(),
    };
  }

  reset() {
    this.stop();
    this.model = "many-to-one";
    this.policy = "round-robin";
    this.syncMode = "semaphore";
    this.speed = 3;
    this.timeSlice = 2;
    this.tick = 0;
    this.running = false;
    this.semaphoreInitial = 1;
    this.semaphoreValue = 1;
    this.monitorOwner = null;
    this.conditionQueue = [];
    this.deadlockMode = false;
    this.logs = [];
    this.threads = DEFAULT_THREADS.map((thread, index) => {
      const cloned = cloneThread(thread);
      cloned.createdAt = index;
      return cloned;
    });
    this.currentThreadId = null;
    this.remapKernelThreads();
    this.log("Simulator reset. Threads are ready to be admitted into the system.");
    this.notify();
  }

  setModel(model) {
    this.model = model;
    this.remapKernelThreads();
    this.log(`Threading model switched to ${this.pretty(model)}.`);
    this.notify();
  }

  setPolicy(policy) {
    this.policy = policy;
    this.log(`CPU scheduling policy switched to ${this.pretty(policy)}.`);
    this.notify();
  }

  setSyncMode(mode) {
    this.syncMode = mode;
    this.semaphoreValue = this.semaphoreInitial;
    this.monitorOwner = null;
    this.conditionQueue = [];
    this.threads.forEach((thread) => {
      thread.enteredCritical = false;
      thread.signalPending = false;
      if (thread.state === "Waiting") {
        thread.state = "Ready";
        thread.blockedReason = "";
      }
    });
    this.currentThreadId = null;
    this.log(`Synchronization mode switched to ${this.pretty(mode)}.`);
    this.notify();
  }

  setSpeed(speed) {
    this.speed = Number(speed);
    if (this.running) {
      this.start();
    } else {
      this.notify();
    }
  }

  setTimeSlice(value) {
    this.timeSlice = Number(value);
    this.log(`Round Robin time slice set to ${this.timeSlice} tick(s).`);
    this.notify();
  }

  setSemaphoreInitial(value) {
    this.semaphoreInitial = Number(value);
    this.semaphoreValue = Number(value);
    this.log(`Semaphore initialized with ${this.semaphoreValue} permit(s).`);
    this.notify();
  }

  createThread() {
    this.threadCounter += 1;
    const thread = nextThreadTemplate(this.threadCounter);
    thread.createdAt = this.tick;
    this.threads.push(thread);
    this.remapKernelThreads();
    this.log(`${thread.id} created in the New state with ${thread.totalWork} work units.`);
    this.notify();
  }

  loadDeadlockDemo() {
    this.stop();
    this.deadlockMode = true;
    this.model = "many-to-many";
    this.policy = "round-robin";
    this.syncMode = "monitor";
    this.timeSlice = 1;
    this.speed = 2;
    this.semaphoreInitial = 1;
    this.semaphoreValue = 1;
    this.monitorOwner = null;
    this.conditionQueue = [];
    this.currentThreadId = null;
    this.tick = 0;
    this.threads = [
      cloneThread({ id: "T1", totalWork: 6, workLeft: 6, state: "New", resourceNeed: "Monitor Lock", actionScript: ["resource", "compute", "resource", "compute"], color: "#d96b40" }),
      cloneThread({ id: "T2", totalWork: 6, workLeft: 6, state: "New", resourceNeed: "Monitor Lock", actionScript: ["resource", "compute", "resource", "compute"], color: "#1b8a7b" }),
      cloneThread({ id: "T3", totalWork: 5, workLeft: 5, state: "New", resourceNeed: "Monitor Lock", actionScript: ["resource", "compute", "resource"], color: "#9969d8" }),
    ];
    this.threadCounter = 3;
    this.remapKernelThreads();
    this.log("Deadlock-style contention demo loaded. Watch multiple threads queue for the monitor.");
    this.notify();
  }

  start() {
    this.stopTimer();
    this.running = true;
    this.timer = window.setInterval(() => this.step(), SPEEDS[this.speed].delay);
    this.notify();
  }

  pause() {
    this.stop();
    this.log("Simulation paused.");
    this.notify();
  }

  stop() {
    this.running = false;
    this.stopTimer();
  }

  stopTimer() {
    if (this.timer) {
      window.clearInterval(this.timer);
      this.timer = null;
    }
  }

  step() {
    // A single step represents one scheduler tick in the simulated OS.
    this.tick += 1;
    this.admitNewThreads();
    this.ageReadyThreads();
    this.updateWaitingThreads();

    const current = this.currentThread();
    if (current && current.state === "Running") {
      this.executeRunningThread(current);
    }

    if (!this.currentThread()) {
      this.scheduleNextThread();
    }

    if (this.threads.every((thread) => thread.state === "Terminated")) {
      this.stop();
      this.log("All threads reached the Terminated state. The simulation has stopped.");
    }

    this.notify();
  }

  admitNewThreads() {
    this.threads.forEach((thread) => {
      if (thread.state === "New" && this.tick - thread.createdAt >= 1) {
        thread.state = "Ready";
        this.log(`${thread.id} moved from New to Ready.`);
      }
    });
  }

  ageReadyThreads() {
    this.threads.forEach((thread) => {
      if (thread.state === "Ready") {
        thread.age += 1;
      }
    });
  }

  updateWaitingThreads() {
    this.threads.forEach((thread) => {
      if (thread.state === "Waiting") {
        thread.waitDuration += 1;
      }
    });

    if (this.syncMode === "semaphore" && this.semaphoreValue > 0) {
      this.wakeNextWaitingThread("Semaphore permit available.");
    }

    if (this.syncMode === "monitor" && !this.monitorOwner) {
      this.wakeNextWaitingThread("Monitor became available.");
    }
  }

  executeRunningThread(thread) {
    thread.workLeft -= 1;
    thread.quantumUsed += 1;
    thread.age = 0;
    this.log(`${thread.id} is running on ${thread.kernelId} and now has ${thread.workLeft} work units left.`);

    if (thread.signalPending || (thread.enteredCritical && Math.random() > 0.55)) {
      this.releaseResource(thread);
    }

    if (thread.workLeft <= 0) {
      thread.state = "Terminated";
      this.releaseResource(thread);
      this.currentThreadId = null;
      this.log(`${thread.id} moved to Terminated.`);
      return;
    }

    if (this.shouldBlockForResource(thread)) {
      // A running thread may request the critical section and get blocked.
      const granted = this.tryAcquireResource(thread);
      if (!granted) {
        this.currentThreadId = null;
        if (this.model === "many-to-one") {
          this.processWideBlock(thread.id);
        }
        return;
      }
    }

    const mustYield = this.policy === "round-robin" && thread.quantumUsed >= this.timeSlice;
    if (mustYield) {
      thread.state = "Ready";
      thread.quantumUsed = 0;
      this.currentThreadId = null;
      this.log(`${thread.id} yielded the CPU after its time slice expired.`);
    }
  }

  scheduleNextThread() {
    const next = this.pickNextReadyThread();
    if (!next) {
      this.log("CPU is idle because no thread is in the Ready state.");
      return;
    }

    next.state = "Running";
    next.quantumUsed = 0;
    next.age = 0;
    this.currentThreadId = next.id;
    this.log(`${next.id} entered the Running state on ${next.kernelId}.`);

    if (this.shouldBlockForResource(next)) {
      const granted = this.tryAcquireResource(next);
      if (!granted) {
        this.currentThreadId = null;
      }
    }
  }

  pickNextReadyThread() {
    const readyThreads = this.threads.filter((thread) => thread.state === "Ready");
    if (!readyThreads.length) {
      return null;
    }

    if (this.policy === "fcfs") {
      return readyThreads.sort((a, b) => a.createdAt - b.createdAt || a.id.localeCompare(b.id))[0];
    }

    return readyThreads.sort((a, b) => b.age - a.age || a.id.localeCompare(b.id))[0];
  }

  shouldBlockForResource(thread) {
    if (thread.enteredCritical) {
      return false;
    }

    const scriptedAction = thread.actionScript[thread.scriptIndex] ?? "compute";
    const randomHit = Math.random() > 0.73;
    return scriptedAction === "resource" || randomHit;
  }

  tryAcquireResource(thread) {
    return this.syncMode === "semaphore" ? this.handleSemaphore(thread) : this.handleMonitor(thread);
  }

  handleSemaphore(thread) {
    if (this.semaphoreValue > 0) {
      this.semaphoreValue -= 1;
      thread.enteredCritical = true;
      thread.signalPending = true;
      thread.scriptIndex += 1;
      this.log(`${thread.id} performed wait() and entered the critical section. Semaphore = ${this.semaphoreValue}.`);
      return true;
    }

    this.blockThread(thread, "Waiting for semaphore permit.");
    return false;
  }

  handleMonitor(thread) {
    if (!this.monitorOwner) {
      this.monitorOwner = thread.id;
      thread.enteredCritical = true;
      thread.signalPending = true;
      thread.scriptIndex += 1;
      this.log(`${thread.id} entered the monitor. Other threads must wait on the condition queue.`);
      return true;
    }

    this.blockThread(thread, "Monitor occupied. Waiting on condition variable.");
    return false;
  }

  releaseResource(thread) {
    if (!thread.enteredCritical) {
      return;
    }

    if (this.syncMode === "semaphore") {
      this.semaphoreValue += 1;
      this.log(`${thread.id} performed signal(). Semaphore = ${this.semaphoreValue}.`);
    }

    if (this.syncMode === "monitor" && this.monitorOwner === thread.id) {
      this.monitorOwner = null;
      this.log(`${thread.id} exited the monitor and signalled one waiting thread.`);
    }

    thread.enteredCritical = false;
    thread.signalPending = false;
    this.wakeNextWaitingThread("A blocked thread was notified.");
  }

  blockThread(thread, reason) {
    thread.state = "Waiting";
    thread.quantumUsed = 0;
    thread.blockedReason = reason;
    thread.waitDuration = 0;
    if (!this.conditionQueue.includes(thread.id)) {
      this.conditionQueue.push(thread.id);
    }
    this.log(`${thread.id} moved to Waiting. ${reason}`);
  }

  wakeNextWaitingThread(reason) {
    const nextId = this.conditionQueue.shift();
    if (!nextId) {
      return;
    }

    const thread = this.threads.find((item) => item.id === nextId);
    if (!thread || thread.state !== "Waiting") {
      return;
    }

    thread.state = "Ready";
    thread.blockedReason = "";
    thread.waitDuration = 0;
    this.log(`${thread.id} woke up and returned to Ready. ${reason}`);
  }

  processWideBlock(originThreadId) {
    this.threads.forEach((thread) => {
      if (thread.id !== originThreadId && thread.state === "Ready") {
        thread.state = "Waiting";
        thread.blockedReason = "Blocked indirectly because many-to-one shares one kernel thread.";
        if (!this.conditionQueue.includes(thread.id)) {
          this.conditionQueue.push(thread.id);
        }
      }
    });
    this.log("Many-to-One blocking: one stalled kernel thread forced the remaining ready threads to wait.");
  }

  currentThread() {
    return this.threads.find((thread) => thread.id === this.currentThreadId) ?? null;
  }

  remapKernelThreads() {
    // User-to-kernel mappings depend on the selected threading model.
    const count = this.kernelThreadCount();
    this.threads.forEach((thread, index) => {
      if (this.model === "many-to-one") {
        thread.kernelId = "K1";
      } else if (this.model === "one-to-one") {
        thread.kernelId = `K${index + 1}`;
      } else {
        thread.kernelId = `K${(index % count) + 1}`;
      }
    });
  }

  kernelThreadCount() {
    if (this.model === "many-to-one") {
      return 1;
    }
    if (this.model === "one-to-one") {
      return this.threads.length;
    }
    return Math.max(2, Math.ceil(this.threads.length / 2));
  }

  buildKernelThreads() {
    const count = this.kernelThreadCount();
    return Array.from({ length: count }, (_, index) => {
      const id = `K${index + 1}`;
      const runningThread = this.threads.find((thread) => thread.kernelId === id && thread.state === "Running");
      return { id, threadId: runningThread?.id ?? "Idle" };
    });
  }

  log(message) {
    this.logs.unshift({ tick: this.tick, message });
    this.logs = this.logs.slice(0, 30);
  }

  pretty(value) {
    return value
      .split("-")
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join("-");
  }
}
